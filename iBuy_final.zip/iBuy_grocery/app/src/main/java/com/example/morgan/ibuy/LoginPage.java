package com.example.morgan.ibuy;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.gson.Gson;

import java.util.LinkedList;

public class LoginPage extends AppCompatActivity {


    Button login;
    public static final String myPrefrences = "MY_PREF";
    //Gson gson = new Gson();
    EditText email, password;
   // User currentUser = new User("0000", "0000", "0000");
    SharedPreferences sharedPref;

    LinkedList<User> user_database;

    // TODO: Check user password and refrence the right user
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_page);
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);

        sharedPref = getSharedPreferences(myPrefrences, Context.MODE_PRIVATE);


        //user_database = gson.fromJson(json,LinkedList.class);

        login = (Button) findViewById(R.id.gotologin);
        login.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                 if(!email.getText().toString().isEmpty() && !password.getText().toString().isEmpty()){
                     try{
                         String trying = sharedPref.getString(email.getText().toString(), password.getText().toString());
                         Intent LoginToSetHome = new Intent(LoginPage.this, GroceryPage.class);
                         startActivity(LoginToSetHome);
                         Toast.makeText(LoginPage.this, "Welcome back!", Toast.LENGTH_LONG).show();


                     } catch (Exception e){


                     }
                 }
                    //Toast.makeText(LoginPage.this, "Welcome back " + currentUser.getName(), Toast.LENGTH_LONG).show();

                    //findUserName(user_database, email.getText().toString(),password.getText().toString());

                //}
                else {
                    Toast.makeText(LoginPage.this, "Please fill the username and password", Toast.LENGTH_LONG).show();

                }

            }
        });



    }

    // returns true if it finds the user.
   /* public boolean findUserName(LinkedList<User> accounts, String userEmail, String password){

        User pew;

        for (int i = 0; i<accounts.size();i++){
            pew = accounts.get(i);
            if (pew.getEmail().equals(userEmail) && pew.getPassword().equals(password)){
                currentUser = pew;
                return true;

            }

        }

        return false;
    } */
}
