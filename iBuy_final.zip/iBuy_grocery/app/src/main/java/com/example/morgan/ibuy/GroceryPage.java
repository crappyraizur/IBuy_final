package com.example.morgan.ibuy;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class GroceryPage extends AppCompatActivity {


    private ListView mShoppingList;
    private EditText mItemEdit;
    private Button mAddButton;
    private EditText quantity;
    private ArrayAdapter<ItemClass> mAdapter;
    private ArrayList<ItemClass> itemList;
    private ArrayList<ArrayAdapter> nope;
    static ItemClass items;
    private static int counter;

    // TODO: Check if user input empty, tell them to fill whole thing
    // TODO: Add ability to Strikethrough item
    // TODO: Save state of arrayAdapter

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grocery_page);

        mShoppingList = (ListView) findViewById(R.id.shopping_listView);
        mItemEdit = (EditText) findViewById(R.id.item_editText);
        mAddButton = (Button) findViewById(R.id.add_button);
        quantity = (EditText) findViewById(R.id.item_quantity);

        mAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1);
        mShoppingList.setAdapter(mAdapter);

        mAddButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String item = mItemEdit.getText().toString();
                items = new ItemClass(item, 3,Integer.parseInt(quantity.getText().toString()), "zizo" );
                mAdapter.add(items);
                mAdapter.notifyDataSetChanged();
                mItemEdit.setText("");
                quantity.setText("");
                counter++;
            }
        });

        mShoppingList.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                ItemClass delItem = mAdapter.getItem(position);
                mAdapter.remove(mAdapter.getItem(position));
                mAdapter.notifyDataSetChanged();
                Toast.makeText(GroceryPage.this, "You deleted : " + delItem.getItemName(), Toast.LENGTH_SHORT).show();
            }
        });





    }
}
