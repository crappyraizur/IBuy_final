package com.example.morgan.ibuy;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.LinkedList;

/**
 * Created by ziizo on 11/15/2017.
 */

public class User implements Parcelable {
    // do not know what we'll use this for
    String email;
    String name;
    String password;
    public User(String email,String userName, String password){
        this.email = email;
        name = userName;
        this.password = password;
    }

    String getEmail() {
        return email;
    }

    String getName(){
        return name;
    }
    String getPassword(){
        return password;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {

    }
}
