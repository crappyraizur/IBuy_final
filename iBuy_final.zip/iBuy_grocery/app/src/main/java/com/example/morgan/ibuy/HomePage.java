package com.example.morgan.ibuy;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class HomePage extends AppCompatActivity {

    Button login_button;
    Button signup_button;
    Button about_button;

    // TODO: Make the xml page a little nicer.
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);

        about_button = (Button) findViewById(R.id.about);
        about_button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent homeTOabout = new Intent(HomePage.this, AboutPage.class);
                startActivity(homeTOabout);
            }
        });

        login_button = (Button) findViewById(R.id.login);
        login_button.setOnClickListener (new View.OnClickListener() {
            public void onClick(View v) {
                Intent homeTOlogin = new Intent(HomePage.this, LoginPage.class);
                startActivity(homeTOlogin);
            }
        });

        signup_button = (Button) findViewById(R.id.signup);
        signup_button.setOnClickListener (new View.OnClickListener() {
            public void onClick(View v) {
                Intent homeTOsignup = new Intent(HomePage.this, SignUpPage.class);
                startActivity(homeTOsignup);
            }
        });
    }
}
