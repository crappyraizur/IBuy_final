package com.example.morgan.ibuy;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.LinkedList;

public class SignUpPage extends AppCompatActivity {

    //TODO: Create database using sharedPrefrences to save user names and password this is just a work around.

    EditText enterEmail;
    EditText enterName;
    EditText enterPassword;
    Button signup;

    public static final String myPrefrences = "MY_PREF";
    LinkedList<User> user_database;
    User userAccount;
    SharedPreferences sharedPref;
    //String hotmail = ".com";
    Gson gson = new Gson();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup_page);

        enterEmail = (EditText) findViewById(R.id.enterEmail);
        enterName = (EditText) findViewById(R.id.enterNickname);
        enterPassword = (EditText) findViewById(R.id.enterPassword);
        signup = (Button) findViewById(R.id.signup);
        user_database = new LinkedList<User>();


        Context context = SignUpPage.this;
        SharedPreferences sharedPref = context.getSharedPreferences(myPrefrences, Context.MODE_PRIVATE);
        final SharedPreferences.Editor dataEditor = sharedPref.edit();



        signup.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (!enterEmail.getText().toString().isEmpty() && !enterName.getText().toString().isEmpty() && !enterPassword.getText().toString().isEmpty()){
                    userAccount = new User(enterEmail.getText().toString(), enterName.getText().toString(),enterPassword.getText().toString());

                    Toast.makeText(SignUpPage.this, "Thank you " + userAccount.getName() + " account created succesfully!", Toast.LENGTH_SHORT).show();
                    //user_database.add(userAccount);
                    //String json = gson.toJson(user_database);
                    dataEditor.putString(userAccount.getEmail(), userAccount.getPassword());
                    dataEditor.commit();

                    Intent signupToHome = new Intent(SignUpPage.this, HomePage.class);
                    startActivity(signupToHome);
                }
                else {
                    Toast.makeText(SignUpPage.this, "Please fill form", Toast.LENGTH_SHORT).show();

                }

            }
        });




    }
}
