package com.example.morgan.ibuy;

/**
 * Created by ziizo on 11/15/2017.
 */

public class ItemClass {
    String itemName;
    String itemAuthor;
    String itemPriority;
    int itemQuantity;


    public ItemClass(String name, int priority, int quantity, String author) {
        itemName = name;
        itemAuthor = author;
        itemQuantity = quantity;
        itemPriority = priorityGiver(priority);

    }


    // picks the priority
    private String priorityGiver(int priority){
        if (priority == 1){
            return "Now.";
        }
        else if (priority == 2){
            return "Tonight.";
        }
        return "Anytime";
    }

    public String getItemName(){
        return itemName;
    }

    public String getItemAuthor(){
        return itemAuthor;
    }

    public int getItemQuantity() {
        return itemQuantity;
    }

    public String getItemPriority(){
        return itemPriority;
    }

    @Override
    public String toString() {
        return String.format("%s \nQuantity %s. When: %s     User: %s", getItemName(), getItemQuantity(),getItemPriority(), getItemAuthor());
    }
}
