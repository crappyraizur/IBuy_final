package com.example.morgan.ibuy;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class SetupHomePage extends AppCompatActivity {


    // TODO: Don't know shit about how we can implement this without brainfarting every 5 minutes
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setup_home_page);
    }
}
